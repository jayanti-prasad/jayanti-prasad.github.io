function  soup_menu(){
var n =7;
var item = new Array (7);
item[0]="";
item[1]="Peas-Soup";
item[2]="Rasam";
item[3]="Tomato-Soup";
item[4]="EMPTY";
item[5]="EMPTY";
item[6]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
