<?php
include ("update.php");
?>

 

<?php 

$titem= array("breakfast","tiffin","main1","main2","vegdry","veggravy","dal","soup","sweet","nonveg","salad","misc");

for($i=0; $i< 12; $i++){
  $itemname = $titem[$i]; 
  if ($_POST[$itemname] !=""){
    $filename = $itemname.".list";
    $file_handle = fopen($filename,"a+");
    fwrite($file_handle,$_POST[$itemname]);
    fwrite($file_handle,"\n");
    fclose($file_handle);
    update_item($itemname); 
    echo '<li> You have successfully added <font color="red">';
    echo $_POST[$itemname] ;
    echo "</font> from ";
    echo $itemname; 
    echo "list !<br>";
  
  }

 }

?>

<br><br>
<center>
<a href="menu.html">Menu </a> | <a href="edit_menu.php"> Add & Remove items </a>|
<a href="menu_help.html"> Help</a>|<a href="suggestion_form.html"> Suggestions </a>|<a href="menu_guidelines.html"> Guidelines </a>|
</center>
</p>

<p>
<hr width="90%">
 </p>
<p>
<script language="javascript" type="text/javascript">
 document.write("This document was last modified on "+document.lastModified);
 </script>
 </p>



</body>
</html>
