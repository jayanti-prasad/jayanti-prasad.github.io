<?php 
function update_item($nitem){
  
  $infile = $nitem.".list"; 
  $outfile = $nitem.".js";
 
  $fh=fopen($infile,"r");
  
  $i=0; 
  
  while (!feof($fh)) {
    $line = fgets($fh);
    $line = str_replace("\n","",$line);
    $titem[$i]= $line;
    $i++;
    
  }
  
  $n=$i;

  fclose($fh);


  // close the existing list file 
  // open the javascript file for the corresponding file 

  $fp = fopen($outfile,"w");
  $func_name = $nitem."_menu()";
  
  fwrite($fp,"function  ");
  fwrite($fp,$func_name);
  fwrite($fp,"{\n");
  fwrite($fp,"var n =");
  fwrite($fp,$n);
  fwrite($fp,";\n");
  
  fwrite($fp,"var item = new Array (");
  fwrite($fp,$n);
  fwrite($fp,");\n");
  
  for($i=0; $i< $n; $i++){
    fwrite($fp,"item[");
    fwrite($fp,$i);
    fwrite($fp,']="');
    fwrite($fp,$titem[$i]);
    fwrite($fp,'";');
    fwrite($fp,"\n");
    
  }
  
  fwrite($fp,"for(i=0; i < n; i++){\n");
  fwrite($fp,'document.write("<option>" +item[i]);') ;
  fwrite($fp,"}\n");
  fwrite($fp,"}\n");
  
  fclose($fp);
  
}

?> 

