<html>
<head>
<title> Menu maker </title>
<style type="text/css">


table {
     width : 80%; 
     height : 80%;  
     border :1; 
     background: white;
     /*margin: 2cm 1cm 2cm 4cm;*/
   }

</style>


</head>

<body>

<?php


$day1=$_POST["day1"]; $date1=$_POST["date1"]; $month1=$_POST["month1"]; $year1=$_POST["year1"];
$day2=$_POST["day2"]; $date2=$_POST["date2"]; $month2=$_POST["month2"]; $year2=$_POST["year2"];



$breakfast = $_POST["breakfast"];

$main1L = $_POST["main1L"]; $main2L = $_POST["main2L"]; 
$vegdryL= $_POST["vegdryL"]; $veggravyL= $_POST["veggravyL"];
$dalL  = $_POST["dalL"]; $soup  = $_POST["soup"];
$sweet = $_POST["sweet"]; $misc  = $_POST["misc"]; 

$main1D = $_POST["main1D"]; $main2D = $_POST["main2D"];
$vegdryD= $_POST["vegdryD"]; $veggravyD= $_POST["veggravyD"];
$dalD   = $_POST["dalL"]; $nonveg  = $_POST["nonveg"];

$tiffin  =$_POST["tiffin"];

$days = array(0 => 'Monday',   'Tuesday', 'Wednesday','Thursday', 'Friday',  'Saturday', 'Sunday');

echo '<center>';
echo '<h3><font color="blue"> Inter-University Centre for Astronomy and Astrophysics (IUCAA) </font> </h3>';

echo '<h2><font color="red"> Canteen Menu  </font> </h2>';

echo "<h4>(".$day1.", ".$date1.", ".$month1.", ".$year1."---".$day2.", ".$date2.", ".$month2.", ".$year2.")</h4>";

echo '<table border="4"><tr bgcolor="yellow" height="5%"> <td bgcolor="green" width="15%"> Days </td> <td width="15%" > Breakfast  </td> <td width="20%"> Lunch  </td> <td width="15%"> Tiffin </td> <td width="20%"> Dinner </td> </tr>';

for($i=0; $i<7; $i++){
 echo '<tr><td  bgcolor="yellow" rowspan="3">';
 echo $days[$i]. '</td><td>'. $breakfast[$i].'</td><td>'. $main1L[$i].", ".$main2L[$i]."</td><td>".$tiffin[$i].'</td><td>'.$main1D[$i].",".$main2D[$i].'</td> </tr>';
echo '<tr><td></td><td>'.$vegdryL[$i].", ".$veggravyL[$i]."</td><td> </td><td>".$vegdryD[$i].", ".$veggravyD[$i].'</td> </tr>';
echo '<tr><td></td><td>'.$dalL[$i].",".$soup[$i].", "."</td><td> </td><td>". $nonveg[$i] .'</td> </tr>';
echo '<tr><td></td><td></td><td>'.$sweet[$i].", ".$misc[$i]."</td><td> </td><td></td> </tr>";
    
}
echo '<tr><td></td><td></td><td> </td><td></td<td> <a href="menu.tex">Tex Download</a>';
echo '</td></tr></table>';


echo '<hr width="90%">';

echo '<a href="menu.html"> Menu </a> | <a href="menu_help.html"> Help </a> | <a href="menu_guidelines.html"> Guidelines </a>';
echo '|<a href="edit_menu.php"> Add & remove items </a> | <a href="suggestion_form.html"> Suggestions </a>'; 
echo '</center>'; 


$fp = fopen("menu.tex","w");
$header1='
\documentclass[10pt]{article}
\usepackage{graphics}
\usepackage{amsmath}
\usepackage{lscape}
\usepackage{pslatex}
\usepackage{color}
\pagestyle{empty}
\begin{document}


\begin{landscape}
\begin{table}{}
\centerline{\large\bf\ Inter-University Centre for Astronomy and Astrophysics (IUCAA) Pune}
\centerline {{\large\bf\ Canteen-Menu} (';
$header2=')}  
\begin{center}
\begin{tabular}{|l|l|l|l|l|} \hline \hline 
{\bf\ Day}  & {\bf\ Breakfast} & {\bf\ Lunch} & {\bf\ Snacks}  & {\bf\ Dinner} \\\  
             &{\it\ 8.30 AM - 9.30 AM}  & {\it\ 1.00 PM -2.00 PM} & {\it\ 6.00 PM-6.30 PM} & {\it\ 8.00 PM-9.00 PM} \\\ \hline \hline ';
$footer='\end{tabular}
\end{center}
\end{table}
\end{landscape} 
\end{document}';
fwrite($fp,$header1);
fwrite($fp,$month1.$date1."---".$month2.$date2);
fwrite($fp,$header2);

for($i=0; $i<7; $i++){
 $line1 = "{\bf  ".$days[$i]."}  &  ".$breakfast[$i]." & ".$main1L[$i].", ".$main2L[$i]."&".$tiffin[$i]."&".$main1D[$i].", ".$main2D[$i];
 $line2 = "                    &                     & ".$vegdryL[$i].", ".$veggravyL[$i]."&            &".$vegdryD[$i].", ".$veggravy[$i];  
 $line3 = "                    &                     & ".$dalL[$i].", ".$soup[$i]."&            &".$dalD[$i].", ".$nonveg[$i];
 $line4 = "                    &                     & ".$sweet[$i].", ".$misc[$i]."&            &";

  fwrite($fp,"\n");
  fwrite($fp,$line1);
  fwrite($fp,'\\\ ');
  fwrite($fp,"\n");
  fwrite($fp,$line2);
  fwrite($fp,'\\\ ');
  fwrite($fp,$line3);
  fwrite($fp,'\\\ ');
  fwrite($fp,$line4);
  fwrite($fp,'\\\ \hline \hline');
}

fwrite($fp,$footer);

fclose($file_handle);


?>





</body>

</html>

