<html>
<head>
<title> Remove items from the menu  </title>

<SCRIPT type="text/javascript" language="JavaScript"  SRC="breakfast.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="main1.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="main2.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="tiffin.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="veggravy.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="vegdry.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="dal.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="soup.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="sweet.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="nonveg.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="salad.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="misc.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="menu_table.js"></SCRIPT>
<SCRIPT type="text/javascript" language="JavaScript"  SRC="datemonthyear.js"></SCRIPT>

<style type="text/css">
   table{
   border: 2;
   
 }
   select{
   width:200px;
   height:30px;
   background-color:white
  }

</style>



</head>
<body>

<?php

include ("update.php");

?>

<center>
<form action="removeitems.php" method="post">
<table>
 <tr bgcolor="yellow">  <td> Category </td>  <td>  Remove </td>  </tr>

 <td bgcolor="yellow"> Breakfast</td> <td>   <select name="breakfast"> <option>  </option>  <?php prnt_list("breakfast")?> </select>  </td>  </tr>
 

<td bgcolor="yellow"> Tiffin </td> <td>  <select name="tiffin"> <option>  </option>  <?php prnt_list("tiffin")?> </select> </td>  </tr>

 <td bgcolor="yellow"> Main course-1 (Rice) </td> <td>  <select name="main1"> <option>  </option>  <?php prnt_list("main1")?> </select> </td>   </tr>

 
 <td bgcolor="yellow"> Main course-2 (Roti) </td> <td> <select name="main2">  <option>  </option>  <?php prnt_list("main2")?> </select> </td>   </tr>


<td bgcolor="yellow"> Dal   </td> <td> <select name="dal">  <option>  </option>  <?php prnt_list("dal")?> </select>  </td>  </tr>


<td bgcolor="yellow"> Veg-Gravy   </td> <td> <select name="veggravy"> <option>  </option> <?php prnt_list("veggravy")?> </select>  </td>  </tr>


<td  bgcolor="yellow"> Veg-Dry   </td> <td> <select name="vegdry"> <option>  </option> <?php prnt_list("vegdry")?> </select>  </td>  </tr> <tr>


<td bgcolor="yellow"> Soup </td> <td> <select name="soup"> <option>  </option> <?php prnt_list("soup")?> </select>  </td>  </tr> <tr>


<td bgcolor="yellow"> Sweets   </td> <td> <select name="sweet"> <option>  </option> <?php prnt_list("sweet")?> </select>  </td>  </tr> <tr>


<td bgcolor="yellow"> Non-Veg   </td> <td> <select name="nonveg"> <option>  </option> <?php prnt_list("nonveg")?> </select>  </td>  </tr> <tr>


<td bgcolor="yellow"> Salad    </td> <td> <select name="salad"> <option>  </option> <?php prnt_list("salad")?> </select>  </td>  </tr> <tr>


<td bgcolor="yellow"> Misc     </td> <td> <select name="misc"> <option>  </option> <?php prnt_list("misc")?> </select>  </td>  </tr> <tr>

<td></td><td>   <input type="submit" name="submit" style="background-color:red" value="Update list"/>  </td> </tr> </table>

</form>

</center>


<?php
 

$titem= array("breakfast","tiffin","main1","main2","vegdry","veggravy","dal","soup","sweet","nonveg","salad","misc");

for($i=0; $i< 12; $i++){

  $itemname = $titem[$i];

  if ($_POST[$itemname] !=""){
    
    $fname = $itemname.".list";
    $delitem=$_POST[$itemname]; 
    
    $fp=fopen($fname,"r"); 
    
    $i=0;
    while (!feof($fp)) {
      $line = fgets($fp);
      $line = str_replace("\n","",$line);
      $line = str_replace(" ","",$line);  
      $delitem = str_replace(" ","",$delitem);
      
      if(strcmp($delitem,$line) !=0){
	$new_list[$i] = $line;
	$i++;
      }  
      
    }
    $n=$i;
    fclose($fp);
    $fname = $itemname.".list";
    $fp=fopen($fname,"w");
    for($i=0;$i <$n; $i++){
      fwrite($fp,$new_list[$i]);
      fwrite($fp,"\n");
    }
    fclose($fp);
    
    update_item($itemname);  
   
    echo '<li> You have successfully removed <font color="red">';
    echo $_POST[$itemname] ;
    echo "</font> from ";
    echo $itemname;
    echo "list !<br>";
    
  } // this was for removing a breakfast item 
  
 }

?>
  

 <?php 

 function prnt_list($input){
   $fname = $input.".list"; 
   $fp=fopen($fname,"r"); 
   while (!feof($fp)) {
     $line = fgets($fp);
     echo "<option>";
     echo $line; 
     echo "</option>"; 
   }
 }


 ?>
 
 
<p><center>
<a href="additem.php">Add items </a> | <a href="menu.html"> Menu </a>|
<a href="menu_help.html"> Help</a>|<a href="suggestion_form.html"> Suggestions </a>|<a href="menu_guidelines.html"> Guidelines </a>|
</center>
</p>

<p>
<hr width="90%">
 </p>
<p>
 <script language="javascript" type="text/javascript">
  document.write("This document was last modified on "+document.lastModified);
  </script>
	   </p>


 
</body>
</html>
