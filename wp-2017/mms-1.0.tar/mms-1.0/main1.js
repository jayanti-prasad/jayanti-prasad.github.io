function  main1_menu(){
var n =20;
var item = new Array (20);
item[0]="";
item[1]="BAINGAN-BHAT";
item[2]="BROWN-FRIED-RICE";
item[3]="GR.PEAS-PULAO";
item[4]="JEERA-RICE";
item[5]="KHICHADI";
item[6]="LEMON-RICE";
item[7]="MASALA-BHAT";
item[8]="PLAIN-RICE";
item[9]="PUDEENA-RICE";
item[10]="RISOTTO";
item[11]="TOMATO-BHAAT";
item[12]="VEG-BIRYANI";
item[13]="VEG-FRIEDRICE";
item[14]="VEG-PULAO";
item[15]="";
item[16]="CONTINENTAL";
item[17]="CHINESE";
item[18]="MARATHI";
item[19]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
