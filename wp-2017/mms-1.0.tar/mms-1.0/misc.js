function  misc_menu(){
var n =9;
var item = new Array (9);
item[0]="";
item[1]="Chinese";
item[2]="Chole-Bhature";
item[3]="Continental";
item[4]="Curd-Rice";
item[5]="Maharashtrian";
item[6]="Pav-Bhaji";
item[7]="";
item[8]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
