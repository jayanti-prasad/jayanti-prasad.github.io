</html>
<head>

<title>Your Feedback</title>
</head>
<body>

<?php

/* Receive the data from the html form   */

   
$name = $_POST["name"];
$about = $_POST["about"];
$comments = $_POST["comments"];


if($name !="" || $comments != ""){
  
  echo '<p>Your entries are as follows: </p>';
  echo 'Name:     '.$name; 
  echo "<br>";
  echo 'About:    '. $about; 
  echo "<br>";
  echo 'Comments: '. $comments; 
 
/* Define this variable to print the message  */

  $msg = '<p> To see your suggestions click <a href="suggestion.html">
here</a>';
  
  $today = date("F j, Y, g:i a"); 
  $fp = fopen('suggestion.html', 'a+');
  
  fwrite($fp,"<li>\n");
  fwrite($fp,'<p>');
  fwrite($fp,$today);
  fwrite($fp,"</p>");
  fwrite($fp,'<p>Name: <b>');
  fwrite($fp, $name);
  fwrite($fp,'</b></p><p> About: ');
  fwrite($fp,$about);
  fwrite($fp,"</p><p>Comments: ");
  fwrite($fp,$comments);
  fwrite($fp,"</p>\n");
  fwrite($fp,'<hr width="90%">');
  fwrite($fp,"</li> <br><br>");
  fclose($fp);
 }else{
  
  echo "Your name  and/or comments are not valid !\n";
  
 }



?>

<?php 

if (isset($msg)) {
  print $msg;
 }
?> 


<p><center>
[<a href="additem.php" target="dynamic" align="right">Add  </a> /<a href="removeitems.php"> Remove </a>]items/
<a href="menu_help.html"> Help</a>] /<a href="menu.html"> Make menu </a> | <a href="suggestion_form.html"> suggestions </a> |
</center>
</p>


</body>
</html>
