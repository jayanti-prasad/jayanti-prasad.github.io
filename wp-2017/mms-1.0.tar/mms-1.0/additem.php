<html>
<head>
<title> Add new items in the menu !  </title>

</head>
<body>

<?php

include ("update.php");

?>

 
<center>
 <form action="additem.php" method="post">
 <table border="2" width="85%">
 <tr bgcolor="yellow">
 <td width="20%"> Categoary  </td> <td width="20%"> Item </td> <td width="39%"> Comments </td> </td><td width="15%">Submitted By</td></tr>
 <td width="20%" bgcolor="yellow"> Breakfast  </td> <td width=20% > <input type="text" name="breakfast" size="31"></td> <td width="39%"> 
    <input type="text" name="bfcomments" size="60"> </td>
    <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>
<tr> <td bgcolor="yellow"> Tiffin   </td> <td width=20% > <input type="text" name="tiffin" size="31"></td> <td width="39%">
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>
<tr> <td bgcolor="yellow">  Main course-1 (Rice)   </td> <td width=20% > <input type="text" name="main1" size="31"></td> <td width="39%">
 <input type="text" name="main1comments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>
<tr> <td bgcolor="yellow"> Main course-2 (Roti) </td> <td width=20% > <input type="text" name="main2" size="31"></td> <td width="39%">
 <input type="text" name="main2comments" size="60"> </td>
  <td width="15%"> <input type="text" name="ser" size="30"> </td>
</tr>
<tr> <td bgcolor="yellow"> Veg-Dry  </td> <td width=20% > <input type="text" name="vegdry" size="31"></td> <td width="39%">
 <input type="text" name="vegdrycomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>
<tr> <td bgcolor="yellow"> Veg-Gravy  </td> <td width=20% > <input type="text" name="veggravy" size="31"></td> <td width="39%">
 <input type="text" name="veggravycomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>
<tr> <td bgcolor="yellow"> Dal   </td> <td width=20% > <input type="text" name="dal" size="31"></td> <td width="39%">
 <input type="text" name="dalcomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>

<tr> <td bgcolor="yellow"> Soup    </td> <td width=20% > <input type="text" name="soup" size="31"></td> <td width="39%">
 <input type="text" name="soupcomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>

<tr> <td bgcolor="yellow"> Sweet    </td> <td width=20% > <input type="text" name="sweet" size="31"></td> <td width="39%">
 <input type="text" name="sweetcomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>

<tr> <td bgcolor="yellow"> Non-Veg  </td> <td width=20% > <input type="text" name="nonveg" size="31"></td> <td width="39%">
 <input type="text" name="nonvegcomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>

<tr> <td bgcolor="yellow"> Salad  </td> <td width=20% > <input type="text" name="salad" size="31"></td> <td width="39%">
 <input type="text" name="saladcomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr>

<tr> <td bgcolor="yellow"> Misc-Spl  </td> <td width=20% > <input type="text" name="misc" size="31"></td> <td width="39%">
 <input type="text" name="misccomments" size="60"> </td>
  <td width="15%"> <input type="text" name="user" size="30"> </td>
</tr><tr><td></td><td> </td><td> </td><td>
<input type="submit" name="submit" style="background-color:red" value="Update list"/>
</td></tr>
</table>

</form>
</center> 


<?php 



$titem= array("breakfast","tiffin","main1","main2","vegdry","veggravy","dal","soup","sweet","nonveg","salad","misc");

for($i=0; $i< 12; $i++){
  
  $itemname = $titem[$i]; 
  if ($_POST[$itemname] !=""){
    
    $filename = $itemname.".list";
        
    $file_handle = fopen($filename,"a+");
    fwrite($file_handle,$_POST[$itemname]);
    fwrite($file_handle,"\n");
    fclose($file_handle);
    update_item($itemname); 
    echo '<li> You have successfully added <font color="red">';
    echo $_POST[$itemname] ;
    echo "</font> from ";
    echo $itemname; 
    echo "list !<br>";
  
  }

 }

?>

<br><br>
<center>
<a href="menu.html">Menu </a> | <a href="removeitems.php"> Remove items </a>|
<a href="menu_help.html"> Help</a>|<a href="suggestion_form.html"> Suggestions </a>|<a href="menu_guidelines.html"> Guidelines </a>|
</center>
</p>


<p>
<hr width="90%">
 </p>
<p>
<script language="javascript" type="text/javascript">
 document.write("This document was last modified on "+document.lastModified);
 </script>
 </p>



</body>
</html>
