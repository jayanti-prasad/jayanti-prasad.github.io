function  salad(){
 var n =8; 
 var items = new Array("Salad","Kheera","Muli","Ankurit-Salad","Fruit-Salad");
 var i;
 
   for(i=0; i < n; i++){
        document.write("<option>" +items[i]);

    } 			 
}



function  soup(){
 var n =8; 
 var items = new Array("","Tomato-Soup","Veg-Soup","Peas-Soup","Rasam");
 var i;
 
   for(i=0; i < n; i++){
        document.write("<option>" +items[i]);

    } 			 
}


function  sweet(){
 var n =10; 
 var items = new Array("","Gulab-Jamun","Rasgulla","Jalebi","Suji-Halwa","Fruit-Custard","Gajar-Halwa","Siwai-Kheer","Rice-Kheer");
 var i;
 
   for(i=0; i < n; i++){
        document.write("<option>" +items[i]);

    } 			 
}

function  non_veg(){
 var n =4; 
 var items = new Array("","Egg-Curry","Mutton","Chicken","Fish");
 var i;
 
   for(i=0; i < n; i++){
        document.write("<option>" +items[i]);

    } 			 
}

function  misc(){
   var n =5;
   var items = new Array("","Pav-Bhaji","Curd-Rice","Continental","Chinese","Maharashtrian");
   var i;

   for(i=0; i < n; i++){
         document.write("<option>" +items[i]);
    }
}

      
