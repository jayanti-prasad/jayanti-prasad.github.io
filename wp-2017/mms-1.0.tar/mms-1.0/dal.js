function  dal_menu(){
var n =23;
var item = new Array (23);
item[0]="CHANA-DAL";
item[1]="CHILKA-MOONG";
item[2]="DAL-FRY";
item[3]="DAL-HARIYALI";
item[4]="DAL-MAHARANI";
item[5]="DAL-MAKHANI";
item[6]="DAL-PALAK";
item[7]="DAL-TADKA";
item[8]="KADI-PAKODA";
item[9]="MIX-DAL";
item[10]="MOON-GDAL";
item[11]="PANCHARATAN-DAL ";
item[12]="PLAIN-DAL";
item[13]="RAJMA-KASMIRE";
item[14]="RASAM";
item[15]="SAMBHAR";
item[16]="SOLEKADI";
item[17]="TUVARDAL";
item[18]="WHOLE-MASOOR";
item[19]="WHOLE-MOONG";
item[20]="";
item[21]="EMPTY";
item[22]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
