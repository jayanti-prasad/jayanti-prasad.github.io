function  salad_menu(){
var n =11;
var item = new Array (11);
item[0]="";
item[1]="Ankurit-Salad";
item[2]="Fruit-Salad";
item[3]="Kheera";
item[4]="Muli";
item[5]="Salad";
item[6]="";
item[7]="";
item[8]="";
item[9]="";
item[10]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
