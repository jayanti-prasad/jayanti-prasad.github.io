function  nonveg_menu(){
var n =21;
var item = new Array (21);
item[0]="BUTTER-CHICKEN";
item[1]="CHIC-HARIYALIBIRYANI";
item[2]="CHICKEN-ACHARI";
item[3]="CHICKEN-ADHARAKI";
item[4]="CHICKEN-BIRYANI";
item[5]="CHICKEN-GINGER";
item[6]="CHICKEN-HOTSOUR";
item[7]="CHICKEN-HYDRABADI";
item[8]="CHICKEN-KADAI";
item[9]="CHICKEN-KOLHAPURI";
item[10]="CHICKEN-MALWANI";
item[11]="CHICKEN-MASALA";
item[12]="CHICKEN-SAGWALA";
item[13]="DUM-URGI";
item[14]="MURGH-MUGLAI";
item[15]="MUTTON-DHANSAK";
item[16]="MUTTON-KOLHAPURI";
item[17]="MUTTON-ROGANJOSH";
item[18]="MUTTON-SHAHIKORMA";
item[19]="";
item[20]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
