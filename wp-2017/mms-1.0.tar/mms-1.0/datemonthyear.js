
   function  date_list(){
     for(i=1; i <= 31 ; i++){
	document.write("<option>" + i);
		
   }
}

  function  year_list(){
          
     for(i=2011; i < 2020  ; i++){
          document.write("<option>" +i);
		
   }
}



 function  day_list(){
    var nday = 7;
    var day = new Array("Monday","Tuesday","Wednesday","Thirsday","Friday","Saturday","Sunday");
    for(i=0; i < nday ; i++){
	document.write("<option>" + day[i]);
   }


}

 function  month_list(){
    var nmonth = 12;
    var month = new Array("Januray","February","March","April","May","June","July","August","September","October","November","December");
  
   for(i=0; i < nmonth ; i++){
	document.write("<option>" + month[i]);
   }


}  













