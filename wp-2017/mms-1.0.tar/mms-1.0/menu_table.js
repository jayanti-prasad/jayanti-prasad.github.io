function day_menu(){
 var nday =7;
 var day = new Array("Monday","Tuesday","Wednesday","Thirsday","Friday","Saturday","Sunday");
 var i;

   for(i=0; i < 7; i++){
        document.write('<tr> <td width="10%"  bgcolor="green" rowspan="4">' + day[i]+'</td>');
        document.write('<td width="15%" bgcolor="yellow">') 
	document.write('<select name=breakfast[] style="width:160px;height:30px"> <option></option>'); 
        breakfast_menu();
        document.write('</select> </td>');

        document.write('<td  width="30%" bgcolor="yellow">');
        document.write('<select name=main1L[] style="width:160px;height:30px">');
//        document.write('<option value="Default">Plain Rice</option>');
        main1_menu(); 
        document.write('</select> </td>');
        
        document.write('<td  width="30%" bgcolor="yellow"> <select name=main2L[] style="width:160px;height:30px">');
 //       document.write('<option value="Default">Phulka</option>');
        main2_menu(); 
        document.write('</select> </td>');
       
        document.write('<td width="15%">  <select name=tiffin[] style="width:160px;height:30px">');
        document.write("<option></option>");
        tiffin_menu();
        document.write('</select> </td>');

	document.write('<td  width="30%" bgcolor="yellow"> <select name=main1D[] style="width:160px;height:30px">');
 //       document.write('<option value="Default"> Plain Rice</option>');
        main1_menu(); 
        document.write('</select> </td>');
         
        document.write('<td  width="30%" bgcolor="yellow"> <select name=main2D[] style="width:160px;height:30px">');
 //       document.write('<option value="Default">Phulka</option>');
        main2_menu(); 
        document.write('</select> </td>');

        document.write('</tr><tr>');  // second line starts 

        document.write('<td width="15%" bgcolor="yellow">  </td>');
        document.write('<td  width="30%" bgcolor="yellow"> <select name=veggravyL[] style="width:160px;height:30px">');
        document.write("<option></option>"); 
        veggravy_menu(); 
        document.write('</select> </td>');
             
        document.write('<td  width="30%" bgcolor="yellow"> <select name=vegdryL[] style="width:160px;height:30px">');
        document.write("<option></option>");  
        vegdry_menu(); 
        document.write('</select> </td>');
          
        document.write('<td width="15%">  </td>');
        document.write('<td  width="30%" bgcolor="yellow"> <select name=veggravyD[] style="width:160px;height:30px">');
        document.write("<option></option>");
        veggravy_menu(); 
        document.write('</select> </td>');
             
        document.write('<td  width="30%" bgcolor="yellow"> <select name=vegdryD[] style="width:160px;height:30px">');
        document.write("<option></option>");
        vegdry_menu(); 
        document.write('</select> </td>');
                
       document.write('</tr><tr>');  
    // third line starts

       document.write('<td width="15%">  </td>');  
       document.write('<td  width="30%" bgcolor="yellow"> <select name=dalL[] style="width:160px;height:30px">');
      // document.write('<option value="Default">Arhar-Chana Dal</option>'); 
       dal_menu(); 
       document.write('</select> </td>');
             
       document.write('<td  width="30%" bgcolor="yellow"> <select name=soup[] style="width:160px;height:30px">');
       document.write("<option></option>");
       nonveg_menu(); 
       document.write('</select> </td>');

       document.write('<td width="15%">  </td>');  

       document.write('<td  width="30%" bgcolor="yellow"> <select name=dalD[] style="width:160px;height:30px">');
       document.write("<option></option>");
       dal_menu(); 
       document.write('</select> </td>');
             
       document.write('<td  width="30%" bgcolor="yellow"> <select name=nonveg[] style="width:160px;height:30px">');
       document.write("<option></option>");
       nonveg_menu(); 
       document.write('</select> </td>');
       document.write('</tr><tr>');  
    // fourth line starts 

       document.write('<td width="15%">  </td>');  
       document.write('<td  width="30%" bgcolor="yellow"> <select name=sweet[] style="width:160px;height:30px">');
       document.write("<option></option>");
       sweet_menu(); 
       document.write('</select> </td>');
             
 //      document.write('<td  width="30%" bgcolor="yellow"> <select name=misc[] style="width:160px;height:30px">');
 //      document.write("<option></option>");
 //      misc_menu(); 
 //      document.write('</select> </td>');
  document.write('<td  width="30%" bgcolor="yellow"> </td>');

       document.write('<td width="15%">  </td>');
       document.write('<td  width="30%" bgcolor="yellow"> <select name=sweet[] style="width:160px;height:30px">');
       document.write("<option></option>");
       sweet_menu();
       document.write('</select> </td>');



  //   document.write('<td width="15%">  </td>');  

       document.write('<td  width="30%" bgcolor="yellow"> </td>');
       document.write('<td  width="30%" bgcolor="yellow"> </td>');
       
       document.write('</tr><tr>');  
   

    }
}
