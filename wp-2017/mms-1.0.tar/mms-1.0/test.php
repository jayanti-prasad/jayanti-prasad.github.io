<html>

<body>

<?php
echo exec('whoami');
echo exec('latex menu.tex');
echo exec('dvi2ps menu.dvi');
?>





</body>
</html>

