function  breakfast_menu(){
var n =13;
var item = new Array (13);
item[0]="Aloo-Paratha";
item[1]="Suji-Upma";
item[2]="Poha";
item[3]="Idle-Sambhar";
item[4]="Gobhi-Paratha";
item[5]="Puri-Sabji";
item[6]="Puri-Chole";
item[7]="Masala-Dosa";
item[8]="Veg-Paratha";
item[9]="Noodles-Upma";
item[10]="Uttapam";
item[11]="";
item[12]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
