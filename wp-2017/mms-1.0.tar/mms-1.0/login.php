</html>
<head>
<title>Welcome </title>
</head>
<body>


<?php

$msg = 'Welcome'; 


if (isset($_POST['submitted']) ) {
  
  if ((!empty($_POST['name'])) && (!empty($_POST['password'])) ) {
    if ((strtolower($_POST['name']) == 'user') && ($_POST['password'] =='user123')){ 
      print '<p>Welcome   '.$_POST['name'];
      echo "! at <h1> IUCAA Canteen page !</h1> \n";

     
      echo "<ul>";
      echo '<li> <a href="menu.html"> Make the menu !</a>';
      echo '<li> <a href="edit_menu.php"> Add & remove  items !</a>';
      echo '<li> <a href="menu_help.html"> Guidelins to use the sofware.</a>';
      echo '<li> <a href="menu_guidelines.html"> Guidelines to make menu  </a>';
      echo '</ui>';



      $_POST = array( );


    } else { // Incorrect!
      
      print '<p> The submitted <font color="red"> User Name</font>  or <font color="red"> password </font> 
do not match !<br/> Go back and try again.</p>';
    }
    
 } else { // Forgot a field.
  
  print '<p>Please make sure you have entered a valid username and password!<br /> Go back and try again.</p>';
  
 }
 
 }

?> 


<?php

if (isset($msg1)) {
   print $msg1;
 }
?>




</body>
</html>

