function  breakfast_menu(){
var n =21;
var item = new Array (21);
item[0]="ALOO-PARATHA";
item[1]="BREAD-BONDA";
item[2]="CORN-UPAMA";
item[3]="IDLI-SAMBHAR";
item[4]="MASALA-DOSA";
item[5]="MEGGI";
item[6]="PHOHA";
item[7]="POORI-BHAJI";
item[8]="SAGOO-KHICHADI";
item[9]="TOMATO-OMLATE";
item[10]="UTTAPAM-CHUTNEY";
item[11]="VADA-SAMBHAR";
item[12]="VADA-SAMBHAR";
item[13]="VDADA-PAV";
item[14]="VEG-CUTLETS";
item[15]="VEG-PARATHA";
item[16]="VEG-UPMA";
item[17]="";
item[18]="";
item[19]="";
item[20]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
