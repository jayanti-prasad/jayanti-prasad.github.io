function  main2_menu(){
var n =5;
var item = new Array (5);
item[0]="";
item[1]="PHULAKA";
item[2]="";
item[3]="PAV-BHAJI";
item[4]="";
for(i=0; i < n; i++){
document.write("<option>" +item[i]);}
}
