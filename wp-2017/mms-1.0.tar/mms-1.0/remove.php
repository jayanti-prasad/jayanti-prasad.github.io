<?php

include ("update.php");

?>

<?php
 

$titem= array("breakfast","tiffin","main1","main2","vegdry","veggravy","dal","soup","sweet","nonveg","salad","misc");

for($i=0; $i< 12; $i++){

  $itemname = $titem[$i];

  if ($_POST[$itemname] !=""){
    
    $fname = $itemname.".list";
    $delitem=$_POST[$itemname]; 
    
    $fp=fopen($fname,"r"); 
    
    $i=0;
    while (!feof($fp)) {
      $line = fgets($fp);
      $line = str_replace("\n","",$line);
      $line = str_replace(" ","",$line);  
      $delitem = str_replace(" ","",$delitem);
      
      if(strcmp($delitem,$line) !=0){
	$new_list[$i] = $line;
	$i++;
      }  
      
    }
    $n=$i;
    fclose($fp);
    $fname = $itemname.".list";
    $fp=fopen($fname,"w");
    for($i=0;$i <$n; $i++){
      fwrite($fp,$new_list[$i]);
      fwrite($fp,"\n");
    }
    fclose($fp);
    
    update_item($itemname);  
   
    echo '<li> You have successfully removed <font color="red">';
    echo $_POST[$itemname] ;
    echo "</font> from ";
    echo $itemname;
    echo "list !<br>";
    
  } // this was for removing a breakfast item 
  
 }

?>
  
 
 
<p><center>
<a href="menu.html">Menu </a> | <a href="edit_menu.php">Add & Remove items </a> | <a href="menu_help.html"> Help</a>|<a href="suggestion_form.html"> Suggestions </a>|<a href="menu_guidelines.html"> Guidelines </a>|
</center>
</p>

<p>
<hr width="90%">
 </p>
<p>
 <script language="javascript" type="text/javascript">
  document.write("This document was last modified on "+document.lastModified);
  </script>
	   </p>


 
</body>
</html>
