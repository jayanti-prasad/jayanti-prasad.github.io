<html>
<head>
<title> Add new items in the menu !  </title>

<style type="text/css">
   table{
   border: 2;

 }
   select{
   width:200px;
   height:30px;
   background-color:white
  }

input{
width:180px;
height:30px;  

}

p {
    border-style: none;
    margin: 1cm 4cm 0cm 2cm; /* top, right, bottom, left */
}


</style>
</head>
<body>

<center>

<h4> <font color="blue">  Add & Remove items </font></h4> 
<table border="4">
<tr>

<td>
<form action="remove.php" method="post">
<table>
<tr bgcolor="yellow">  </tr><tr>
 <td> <select name="breakfast">  <option></option>  <?php prnt_list("breakfast")  ?>  </select>  </td>  </tr>
 <td> <select name="tiffin"><option></option>  <?php prnt_list("tiffin")?> </select> </td>  </tr>
 <td> <select name="main1"><option></option>  <?php prnt_list("main1")?> </select> </td>   </tr>
 <td> <select name="main2"><option></option>  <?php prnt_list("main2")?> </select> </td>   </tr>
 <td> <select name="dal"><option></option>   <?php prnt_list("dal")?> </select>  </td>  </tr>
 <td> <select name="veggravy"><option></option>  <?php prnt_list("veggravy")?> </select>  </td>  </tr>
 <td> <select name="vegdry"><option></option>  <?php prnt_list("vegdry")?> </select>  </td>  </tr> <tr>
 <td> <select name="soup"><option></option>  <?php prnt_list("soup")?> </select>  </td>  </tr> <tr>
 <td> <select name="sweet"><option></option>   <?php prnt_list("sweet")?> </select>  </td>  </tr> <tr>
 <td> <select name="nonveg"><option></option>  <?php prnt_list("nonveg")?> </select>  </td>  </tr> <tr>
<td> <select name="salad"><option></option>  <?php prnt_list("salad")?> </select>  </td>  </tr> <tr>
 <td> <select name="misc"> <option></option> <?php prnt_list("misc")?> </select>  </td>  </tr> <tr>
<td>   <input type="submit" name="submit" style="background-color:red" value="Remove"/>  </td> </tr> </table>
</form>
</td>

<td>
<form action="add.php" method="post">
 <table>
<tr><td bgcolor="yellow"> Breakfast  </td> <td> <input type="text" name="breakfast"></td> </tr>
<tr> <td bgcolor="yellow"> Tiffin   </td> <td> <input type="text" name="tiffin"></td> </tr>
<tr> <td bgcolor="yellow">  Main course-1 (Rice)   </td> <td> <input type="text" name="main1"></td></tr>
<tr> <td bgcolor="yellow"> Main course-2 (Roti) </td> <td> <input type="text" name="main2"></td>  </td> </tr>
<tr> <td bgcolor="yellow"> Dal   </td> <td> <input type="text" name="dal"></td> </tr>
<tr> <td bgcolor="yellow">  Veg-Gravy  </td> <td> <input type="text" name="veggravy"></td> </tr>
<tr> <td bgcolor="yellow"> Veg-Dry  </td> <td> <input type="text" name="vegdry" ></td> </tr>
<tr> <td bgcolor="yellow"> Soup    </td> <td> <input type="text" name="soup"></td>  </tr>
<tr> <td bgcolor="yellow"> Sweet    </td> <td> <input type="text" name="sweet"></td> </tr>
<tr> <td bgcolor="yellow"> Non-Veg  </td> <td> <input type="text" name="nonveg"></td> </tr>
<tr> <td bgcolor="yellow"> Salad  </td> <td> <input type="text" name="salad"></td> </tr>
<tr> <td bgcolor="yellow">  Misc-Spl  </td> <td> <input type="text" name="misc"></td></tr>
<tr> <td bgcolor="grren"></td><td>  <input type="submit" name="submit" style="background-color:red" value="Add"/>
</td>


</tr>
</table>
</form>
</table>
</center>


<?php

 function prnt_list($input){
   $fname = $input.".list";
   $fp=fopen($fname,"r");
   while (!feof($fp)) {
     $line = fgets($fp);
     echo "<option>";
     echo $line;
     echo "</option>";
   }
 }


 ?>




<br><br>
<center>
<a href="menu.html">Menu </a> | <a href="menu_help.html"> Help</a>|<a href="suggestion_form.html"> Suggestions </a>|<a href="menu_guidelines.html"> Guidelines </a>|
</center>
</p>





</body>
</html>
