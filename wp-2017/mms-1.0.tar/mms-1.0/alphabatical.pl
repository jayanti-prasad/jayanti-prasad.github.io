#!/usr/bin/perl


$data=`ls *.list`;

@files=split("\n",$data);

for($i=0; $i < $#files; $i++){
    system ("cat $files[$i] | sort > tmp.list");
    system ("mv tmp.list  $files[$i]");

}



